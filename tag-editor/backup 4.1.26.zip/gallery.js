// gallery.js — Design selection page

async function loadDesigns() {
  const res = await fetch('./designs.json');
  if (!res.ok) throw new Error('Could not load designs.json');
  return res.json();
}

// Thumbnail: full-size tag scaled down with CSS transform
// This guarantees it looks exactly like the editor preview — no separate rendering path.
async function buildThumbnailTag(design) {
  const THUMB_W = 130;
  const W = design.tagDimensions.width;
  const scale = THUMB_W / W;
  const scaledH = Math.round(design.tagDimensions.height * scale);

  // Wrapper clips to thumbnail size
  const wrapper = document.createElement('div');
  wrapper.style.cssText = `
    width: ${THUMB_W}px;
    height: ${scaledH}px;
    overflow: hidden;
    position: relative;
    border-radius: ${Math.round(16 * scale)}px;
  `;

  // Load default photo if design has photo enabled
  let photoDataURL = null;
  if (design.fields.photo && design.fields.photo.enabled) {
    try {
      const res = await fetch('./couple.jpg');
      const blob = await res.blob();
      photoDataURL = await new Promise((resolve) => {
        const reader = new FileReader();
        reader.onload = (e) => resolve(e.target.result);
        reader.readAsDataURL(blob);
      });
    } catch (e) {
      console.warn('Could not load default couple.jpg for thumbnail:', e);
    }
  }

  // Full-size tag element, then scaled down
  const defaultTagline = design.fields.tagline?.defaultValue || 'Forever starts today';
  const sampleValues = { name1: 'Ethan', name2: 'Maria', date: '', tagline: defaultTagline };
  const tagEl = await window.TagRenderer.buildTagElement(design, sampleValues, photoDataURL);

  // Scale from top-left origin and apply shadow to the tag shape
  tagEl.style.transformOrigin = 'top left';
  tagEl.style.transform = `scale(${scale})`;
  tagEl.style.position = 'absolute';
  tagEl.style.top = '0';
  tagEl.style.left = '0';
  tagEl.style.boxShadow = '0 8px 28px rgba(90,60,40,0.22)';

  wrapper.appendChild(tagEl);
  return wrapper;
}

async function buildCard(design, index) {
  const card = document.createElement('div');
  card.className = 'gallery-card';
  card.style.animationDelay = `${index * 0.08}s`;

  // Thumbnail area
  const thumb = document.createElement('div');
  thumb.className = 'gallery-thumb';
  thumb.appendChild(await buildThumbnailTag(design));

  // Card body
  const photoEnabled = design.fields.photo && design.fields.photo.enabled;
  const fontName = design.fields.couple.fontFamily.split(',')[0];
  const featureTags = [
    photoEnabled ? '<span class="feat-tag">📷 Photo</span>' : '',
    `<span class="feat-tag">${design.fields.date.format}</span>`,
    `<span class="feat-tag font-preview" style="font-family: ${design.fields.couple.fontFamily}; font-weight: ${design.fields.couple.fontWeight || 400}; font-size: 0.85rem; letter-spacing: 0; text-transform: none; padding: 6px 12px;">${fontName}</span>`,
  ].filter(Boolean).join('');

  const body = document.createElement('div');
  body.className = 'gallery-card-body';
  body.innerHTML = `
    <h3 class="gallery-card-name">${design.name}</h3>
    <p class="gallery-card-desc">${design.description}</p>
    <div class="gallery-card-tags">${featureTags}</div>
    <button class="btn-select-design" onclick="selectDesign('${design.id}')">
      Customize This Design
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <line x1="5" y1="12" x2="19" y2="12"/>
        <polyline points="12 5 19 12 12 19"/>
      </svg>
    </button>
  `;

  card.appendChild(thumb);
  card.appendChild(body);
  return card;
}

function selectDesign(designId) {
  sessionStorage.setItem('selectedDesignId', designId);
  window.location.href = 'editor.html';
}

async function init() {
  const grid = document.getElementById('galleryGrid');
  try {
    const designs = await loadDesigns();
    
    // Load all fonts from all designs
    const fontURLs = new Set();
    designs.forEach(design => {
      if (design.fonts && Array.isArray(design.fonts)) {
        design.fonts.forEach(url => fontURLs.add(url));
      }
    });
    
    // Create link elements for each font URL
    fontURLs.forEach(url => {
      const link = document.createElement('link');
      link.rel = 'stylesheet';
      link.href = url;
      document.head.appendChild(link);
    });
    
    grid.innerHTML = '';
    // Build all cards and append them
    for (let i = 0; i < designs.length; i++) {
      const card = await buildCard(designs[i], i);
      grid.appendChild(card);
    }
  } catch (err) {
    console.error('Failed to load designs:', err);
    grid.innerHTML = `
      <div class="gallery-error">
        <p>Could not load designs. Make sure <code>designs.json</code> is in the same folder.</p>
        <p style="font-size:0.75rem;opacity:0.6;margin-top:0.5rem">${err.message}</p>
      </div>
    `;
  }
}

window.selectDesign = selectDesign;
document.addEventListener('DOMContentLoaded', init);
