// app.js — Editor page logic

let _currentDesign  = null;
let _photoDataURL   = null;
let _tagRoot        = null;   // the live tag DOM element
let _updateTagTimer = null;

// ─── Bootstrap ────────────────────────────────────────────────────────────────
window.addEventListener('DOMContentLoaded', async () => {
  const designId = sessionStorage.getItem('selectedDesignId');

  try {
    const designs = await fetch('./designs.json').then(r => r.json());
    _currentDesign = designs.find(d => d.id === designId) || designs[0];
  } catch (e) {
    console.error('Could not load designs.json', e);
    return;
  }

  // Load fonts dynamically
  if (_currentDesign.fonts && _currentDesign.fonts.length) {
    const fontUrl = _currentDesign.fonts[0];
    
    // Remove old font link if different
    const oldLink = document.getElementById('designFonts');
    if (oldLink && oldLink.href !== fontUrl) {
      oldLink.remove();
    }
    
    // Create or update font link
    let link = document.getElementById('designFonts');
    if (!link) {
      link = document.createElement('link');
      link.id = 'designFonts';
      link.rel = 'stylesheet';
      document.head.appendChild(link);
    }
    
    // Set the href
    link.href = fontUrl;
  }

  // Update design badge
  const badgeName = document.getElementById('designBadgeName');
  const metaName  = document.getElementById('previewDesignName');
  if (badgeName) badgeName.textContent = _currentDesign.name;
  if (metaName)  metaName.textContent  = _currentDesign.name;

  // Show/hide photo step
  const photoStep = document.getElementById('photoStep');
  if (photoStep) {
    photoStep.style.display = (_currentDesign.fields.photo && _currentDesign.fields.photo.enabled)
      ? 'flex' : 'none';
  }

  // Update tagline placeholder and default value
  const taglineInput = document.getElementById('tagline');
  if (taglineInput && _currentDesign.fields.tagline && _currentDesign.fields.tagline.defaultValue) {
    taglineInput.placeholder = _currentDesign.fields.tagline.defaultValue;
    if (!taglineInput.value) {
      taglineInput.value = _currentDesign.fields.tagline.defaultValue;
    }
  }

  // Load default photo if design has photo enabled
  if (_currentDesign.fields.photo && _currentDesign.fields.photo.enabled) {
    try {
      const res = await fetch('./couple.jpg');
      const blob = await res.blob();
      _photoDataURL = await new Promise((resolve) => {
        const reader = new FileReader();
        reader.onload = (e) => resolve(e.target.result);
        reader.readAsDataURL(blob);
      });
      // Update UI to show photo is loaded
      document.getElementById('photoRemoveBtn').style.display   = 'block';
      document.getElementById('photoUploadLabel').style.display = 'none';
    } catch (e) {
      console.warn('Could not load default couple.jpg:', e);
    }
  }

  // Size the wrapper to match the design
  const wrapper = document.getElementById('tagWrapper');
  if (wrapper) {
    wrapper.style.width  = _currentDesign.tagDimensions.width  + 'px';
    wrapper.style.height = _currentDesign.tagDimensions.height + 'px';
  }

  // Wait for fonts to fully load and render
  // Reduced delay: browsers cache fonts after first load, so subsequent updates are faster
  await new Promise(r => setTimeout(r, 400));

  // Build and mount the tag element
  _tagRoot = await window.TagRenderer.buildTagElement(_currentDesign, _getValues(), _photoDataURL);
  _tagRoot.id = 'theTag';
  if (wrapper) {
    wrapper.innerHTML = '';
    wrapper.appendChild(_tagRoot);
  }

  await _doUpdateTag();
});

// ─── Read form values ─────────────────────────────────────────────────────────
function _getValues() {
  return {
    name1:   (document.getElementById('name1')   || {}).value || '',
    name2:   (document.getElementById('name2')   || {}).value || '',
    date:    (document.getElementById('wdate')   || {}).value || '',
    tagline: (document.getElementById('tagline') || {}).value || '',
  };
}

// ─── Live update ──────────────────────────────────────────────────────────────
function updateTag() {
  clearTimeout(_updateTagTimer);
  _updateTagTimer = setTimeout(_doUpdateTag, 80);
}

async function _doUpdateTag() {
  if (!_currentDesign || !_tagRoot) return;
  await window.TagRenderer.updateTagElement(_tagRoot, _currentDesign, _getValues(), _photoDataURL);

  // Pulse
  _tagRoot.classList.remove('updating');
  requestAnimationFrame(() => requestAnimationFrame(() => _tagRoot.classList.add('updating')));
}

// ─── Photo upload ─────────────────────────────────────────────────────────────
function handlePhotoUpload(event) {
  const file = event.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (e) => {
    _photoDataURL = e.target.result;
    document.getElementById('photoRemoveBtn').style.display   = 'block';
    document.getElementById('photoUploadLabel').style.display = 'none';
    _doUpdateTag();
  };
  reader.readAsDataURL(file);
}

function removePhoto() {
  _photoDataURL = null;
  document.getElementById('photoInput').value               = '';
  document.getElementById('photoRemoveBtn').style.display   = 'none';
  document.getElementById('photoUploadLabel').style.display = 'flex';
  
  // Reload default photo
  if (_currentDesign.fields.photo && _currentDesign.fields.photo.enabled) {
    fetch('./couple.jpg')
      .then(res => res.blob())
      .then(blob => {
        const reader = new FileReader();
        reader.onload = (e) => {
          _photoDataURL = e.target.result;
          _doUpdateTag();
        };
        reader.readAsDataURL(blob);
      })
      .catch(e => console.warn('Could not reload default couple.jpg:', e));
  } else {
    _doUpdateTag();
  }
}

// ─── PDF Generation ───────────────────────────────────────────────────────────
async function generatePDF() {
  const btn = document.getElementById('btnDownload');
  const v   = _getValues();
  const n1  = v.name1 || 'Taylor';
  const n2  = v.name2 || 'Cynthia';
  const filename = `wedding-tags-${n1}-${n2}-${(_currentDesign || {}).id || 'custom'}`
    .toLowerCase().replace(/\s+/g, '-') + '.pdf';

  btn.disabled  = true;
  btn.innerHTML = `
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="animation:spin 1s linear infinite">
      <circle cx="12" cy="12" r="10" stroke-opacity="0.25"/>
      <path d="M12 2a10 10 0 0 1 10 10" stroke-linecap="round"/>
    </svg>
    Generating PDF…`;

  try {
    try { if (document.fonts?.ready) await document.fonts.ready; } catch (_) {}
    
    // Build the tag canvas at full size for high-quality PDF
    const DPI = 300, MM_PER_INCH = 25.4;
    const A4_W_MM = 210, A4_H_MM = 297;
    const COLS = 4, ROWS = 3, MARGIN_MM = 8, GAP_MM = 4;

    const tagW_MM = (A4_W_MM - MARGIN_MM * 2 - GAP_MM * (COLS - 1)) / COLS;
    const tagH_MM = (A4_H_MM - MARGIN_MM * 2 - GAP_MM * (ROWS - 1)) / ROWS;
    
    // Build canvas at PDF print size
    const tagCanvas = await window.TagRenderer.buildTagCanvas(_currentDesign, _getValues(), _photoDataURL);
    
    // Convert canvas to PNG data URL
    const imgData = tagCanvas.toDataURL('image/png');
    
    // Create PDF and add the image to all 12 tag positions
    const { jsPDF } = window.jspdf;
    const pdf = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4', compress: true });

    pdf.setFillColor(255, 255, 255);
    pdf.rect(0, 0, A4_W_MM, A4_H_MM, 'F');

    const ALIAS = 'tag';
    pdf.addImage(imgData, 'PNG', MARGIN_MM, MARGIN_MM, tagW_MM, tagH_MM, ALIAS, 'NONE');
    for (let row = 0; row < ROWS; row++) {
      for (let col = 0; col < COLS; col++) {
        if (row === 0 && col === 0) continue;
        pdf.addImage(imgData, 'PNG',
          MARGIN_MM + col * (tagW_MM + GAP_MM),
          MARGIN_MM + row * (tagH_MM + GAP_MM),
          tagW_MM, tagH_MM, ALIAS, 'NONE');
      }
    }

    pdf.setFontSize(5);
    pdf.setTextColor(180, 160, 140);
    pdf.text(
      `Tag & Bloom · ${(_currentDesign || {}).name || 'Custom'} · 12 Custom Wedding Tags · Print at 100% on A4`,
      A4_W_MM / 2, A4_H_MM - 2.5, { align: 'center' }
    );
    pdf.save(filename);

  } catch (err) {
    console.error('PDF generation failed:', err);
    alert(`Oops — could not generate the PDF.\n\n${err?.message || ''}`);
  } finally {
    btn.disabled  = false;
    btn.innerHTML = `
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/>
        <polyline points="7 10 12 15 17 10"/>
        <line x1="12" y1="15" x2="12" y2="3"/>
      </svg>
      Download PDF — 12 Tags`;
  }
}

window.generatePDF       = generatePDF;
window.updateTag         = updateTag;
window.handlePhotoUpload = handlePhotoUpload;
window.removePhoto       = removePhoto;
